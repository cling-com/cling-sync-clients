# quoted

Extracted from `go/src/cmd/go/internal/base/` (related to `cache`).

Only the function `IsETXTBSY` is extracted.

## History

- https://github.com/golangci/golangci-lint/pull/5576
  - sync go1.24.1
