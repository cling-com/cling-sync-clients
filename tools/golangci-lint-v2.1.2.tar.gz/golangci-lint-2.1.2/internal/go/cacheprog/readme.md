# quoted

Extracted from `go/src/cmd/go/internal/cacheprog/` (related to `cache`).
This is just a copy of the Go code without any changes.

## History

- https://github.com/golangci/golangci-lint/pull/5576
  - sync go1.24.1
