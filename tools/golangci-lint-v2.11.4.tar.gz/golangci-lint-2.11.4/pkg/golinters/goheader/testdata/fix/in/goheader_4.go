/*
	Copyright 2024 The Awesome Project Authors

	Use of this source code is governed by LICENSE.md
*/

//golangcitest:args -Egoheader
//golangcitest:expected_exitcode 0
//golangcitest:config_path testdata/goheader-fix.yml
package p
