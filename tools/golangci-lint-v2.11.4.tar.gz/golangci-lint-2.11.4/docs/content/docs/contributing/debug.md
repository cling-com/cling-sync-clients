---
title: Debugging
weight: 5
aliases:
  - /contributing/debug/
---

You can see a verbose output of linter by using `-v` option.

```bash
golangci-lint run -v
```

If you would like to see more detailed logs you can use the environment variable `GL_DEBUG`.  
Its value is a list of debug tags.

The existing debug tags are documented in the following file: [/pkg/logutils/logutils.go](https://github.com/golangci/golangci-lint/blob/HEAD/pkg/logutils/logutils.go)

For example:

```bash
GL_DEBUG="loader,gocritic" golangci-lint run
```

```bash
GL_DEBUG="loader,env" golangci-lint run
```
